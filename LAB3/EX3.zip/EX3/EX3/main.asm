; Replace with your application code
.EQU OUTPORT = PORTD
.EQU OUTDDR = DDRD
.EQU INPIN = PIND

.EQU OUTPORT_ENABLE = PORTB
.EQU DDR_ENABLE = DDRB


.equ LED7SEGLatchPORT = PORTB 
.equ LED7SEGLatchDIR = DDRB
.equ nLE0Pin = 4 
.equ nLE1Pin = 5 

.ORG 0
RJMP MAIN
.ORG 0x001A
RJMP TIMER_1_OCPA_ISR
.ORG 0x0040
MAIN:
	LDI R16, HIGH(RAMEND)
	OUT SPH, R16
	LDI R16, LOW(RAMEND)
	OUT SPL, R16
	LDI R16, 0x0F
	RCALL led7seg_portinit
	LDI R16, 0xFF;
	OUT OUTDDR, R16; 
	
	

	
	LDI R17, 0x00
	STS OCR1AH, R17; 
	LDI R17, 0xFF
	STS OCR1AL, R17;

	LDI R17, 0x02
	STS  TCCR1A, R17
	LDI R17, 0x05
	STS  TCCR1B, R17
	SEI
	LDI R17, (1<<OCIE1A)
	STS TIMSK1, R17
	LDI R25, 0x00
	LDI		R18, 4; the value of segment Red using
START:
	mov R17, R25
	RCALL SCAN_4LA
	RJMP START

TIMER_1_OCPA_ISR:
	PUSH R17
	CPI R18, 0
	BRNE NEXT
	LDI R18, 4
NEXT:
	LDI R17, 0x00
	STS TCCR1B, R17
	LDI R17, 0x00
	STS OCR1AH, R17; 
	LDI R17, 0xFF
	STS OCR1AL, R17;
	LDI R17, 0x05
	STS TCCR1B, R17
	POP R17
	DEC R18
	; code th m PC0
ENDING:
	RETI


SCAN_4LA:
	PUSH R17
;	RCALL	BCD_UNP
	
LOOP:
	LDI		R17, 0xFF; turn of all led
	OUT		OUTPORT, R17
	CPI		R18, 3
	BRNE	DISPLAY_ten_units
	LDI		R26, 0
	LDI		R27, 4
	RCALL	display_7seg
	OUT		OUTPORT, R17
	RJMP	Dlscan
DISPLAY_ten_units:
	CPI		R18, 2
	BRNE	DISPLAY_hundred_units
	LDI		R26, 1
	LDI		R27, 3
	RCALL	display_7seg
	OUT		OUTPORT, R17
	RJMP	Dlscan
DISPLAY_hundred_units:
	CPI		R18, 1
	BRNE	DISPLAY_thousand_units
	LDI		R26, 2
	LDI		R27, 2
	RCALL	display_7seg
	OUT		OUTPORT, R17
	RJMP	Dlscan
DISPLAY_thousand_units:
	CPI		R18, 0
	BRNE	Dlscan
	LDI		R26, 3
	LDI		R27, 1
	RCALL	display_7seg
	OUT		OUTPORT, R17
Dlscan:	
	POP R17
	RET

led7seg_portinit: 
	push r20 
	ldi r20, 0b11111111 ; SET led7seg PORT as output
	out OUTDDR, r20 
	in r20, LED7SEGLatchDIR ; read the Latch Port direction register
	ori r20, (1<<nLE0Pin) | (1 << nLE1Pin) 
	out LED7SEGLatchDIR,r20 
	pop r20 
	ret

display_7seg: 
	push r16 ; Save the temporary register
 ; Look up the 7-segment code for the value in R18
 ; Note that this assumes a common anode display, where a HIGH output turns OFF the segment
 ; If using a common cathode display, invert the values in the table above
	ldi zh,high(TAB_7SA<<1) ; 
	ldi zl,low(TAB_7SA<<1) ;
	clr r16 
	add r30, r27 
	adc r31,r16 
	lpm r16, z 
	out OUTPORT,r16 
	sbi LED7SEGLatchPORT,nLE0Pin 
	nop
	cbi LED7SEGLatchPORT,nLE0Pin 
	ldi zh,high(table_7seg_control<<1) ; 
	ldi zl,low(table_7seg_control<<1) ;
	clr r16 
	add r30, r26 
	adc r31,r16 
	lpm r16, z 
	out OUTPORT,r16 
	sbi LED7SEGLatchPORT,nLE1Pin 
	nop
	cbi LED7SEGLatchPORT,nLE1Pin 
	pop r16 ; Restore the temporary register
	ret ; Return from the function

	TAB_7SA:
	.DB	0xC0, 0xF9, 0xA4, 0xB0, 0x99, 0x92
	.DB 0x82, 0xF8, 0x80, 0x90, 0x88, 0x83
	.DB	0xC6, 0xA1, 0x86, 0x8E

	table_7seg_control: 
 .DB 0b00001110,0b00001101, 0b00001011, 0b00000111 
