.EQU LCD_PORT=PORTB       ; Define LCD port
.EQU LCD_DDR=DDRB         ; Define LCD data direction
.EQU RS=0                 ; Register Select pin
.EQU RW=1                 ; Read/Write pin
.EQU EN=2                 ; Enable pin
;-----------------------
	.EQU	ADC_PORT=PORTA
	.EQU	ADC_DR=DDRA
	.EQU	ADC_IN=PINA		
	.EQU	VALUE_CNT = 250	
	.EQU	TF	=	31250
	.ORG	0
	RJMP	MAIN
	.ORG	0X40
MAIN:	
	LDI		R16,HIGH(RAMEND);??a stack l�n v�ng ?/c cao
	OUT		SPH,R16
	LDI		R16,LOW(RAMEND)
	OUT		SPL,R16
			
// Configure UART, configure the ADC pins as input, configure other in/out pins as per the requirements.(Todo: Write UART configuration code)
	CALL	USART_Init

// Configure the timer, select the appropriate timer and mode, and configure the auto trigger settings. (Todo: Write Timer configuration code)
	LDI		R16,HIGH(TF) ;n?p OCR1A/B byte cao gi� tr? ??t tr??c
	STS		OCR1AH,R16
	STS		OCR1BH,R16
	LDI		R16,LOW(TF) ;n?p OCR1A/B byte th?p gi� tr? ??t tr??c
	STS		OCR1AL,R16
	STS		OCR1BL,R16
	LDI		R16,0X00 ;Timer1 mode CTC4
	STS		TCCR1A,R16
	LDI		R16,0B00001100 ;Timer1 mode CTC4,N=256,ch?y Timer1
	STS		TCCR1B,R16
	
// Configure the ADMUX register for the ADC, set Vref to Avcc = 5V, select single-ended ADC1, gain x1, and shift the result right. 
// 5V is 01, 1.1 is 10, 11 is 2.56V is REFS, ADC0 gain 1x is MUx 4:0 10000
	LDI		R16, (1<<REFS1) | (1<<REFS0) | (0<<MUX3) | (0<<MUX0) | (1<<MUX4)
	STS		ADMUX, R16

// Enable ADC operation: Bit 7 must be set. Bit 6 must be cleared. Enable auto-trigger mode. Set the ADC conversion complete flag (bit 4). 
	
	LDI		R16, (1<<ADEN) | (1<<ADSC) | (1<<ADATE)
	STS		ADCSRA, R16
// Disable interrupts (bit 3), and select the ADC clock prescaler (bits 2..0). 
	
// Configure ADCSRB register. Select the appropriate trigger source for auto-trigger.
	LDI		R16,0X05 ;ngu?n t?o k�ch OCF1B
	STS		ADCSRB,R16
// Configure the DIDR0 register. Write 1 to disable digital mode on the ADC pins to save power.
	LDI		R16, (1<<ADC0D) | (1<<ADC1D)
	STS		DIDR0, R16
;-----------------------LCD-----------------------------
/*
Connect port A to the LCD: RS=PA0, RW=PA1, EN=PA2, Data[4:7] = PA4:PA7
=> Declare PA0, PA1, PA2, PA4, PA5, PA6, PA7 as output, and initialize values as follows: Data = 0, RS=0, RW=1, EN=0.
*/	
	LDI R16, 0xFF
	OUT LCD_DDR, R16
	LDI R16, 0x00
	OUT LCD_PORT, R16
	CBI LCD_PORT, RS
	SBI LCD_PORT, RW
	CBI LCD_PORT, EN
// Call the subroutine to initialize the power (POWERUP_LCD_4BIT) for 4-bit LCD mode. Refer to the curriculum for specifics. Do not call this subroutine; otherwise, the LCD will not display anything.
	call POWERUP_LCD_4BIT
// Call the subroutine to configure the LCD.
	call INIT_LCD_4BIT
// Call the command to set the DDRAM pointer to 0x00.
	LDI R17, 0x00
	call WRITE_COMMAND
	

// Call the command to set the DDRAM pointer to 0x00.
	LDI R17, 0x00
	call WRITE_COMMAND
	

// Below is the code to reference the table and display characters from the first row on the LCD until a 0x00 character is encountered.
    LDI ZH, HIGH(LINE1 << 1)   ; Load high byte of LINE1 address into ZH
    LDI ZL, LOW(LINE1 << 1)    ; Load low byte of LINE1 address into ZL
DISPLAY_LINE1:
    LPM R17, Z+                ; Load character from the program memory into R17
    CPI R17, $00               ; Compare R17 with 0x00
    BREQ NEWLINE               ; Branch to NEWLINE if equal
    CALL WRITE_DATA            ; Call to write data to LCD
    RJMP DISPLAY_LINE1         ; Repeat the process for the next character
NEWLINE:
// Similarly, write code to display on the second row
; R18 stores the number of times the button is pressed
    LDI R18, 0
    ; R19 is a constant for converting to ASCII; note that the count from 0, 1, ... displayed on the LCD needs to be incremented by 48 (decimal).
    LDI R19, 48 

;----------------------LOOP-----------------------------
LP:
	LDI		R17, 0xC0
	CALL	WRITE_COMMAND
	LDS		R16, ADCSRA
	SBRS	R16, ADIF
	RJMP	LP
	SBR		R16, ADIF
	STS		ADCSRA,R16
	CALL	DISPLAY_V
	CALL	TIMER1_INIT

	RJMP LP
;CPU clock is 8Mhz
TIMER1_INIT:
	
	IN		R17,TIFR1 ;??c c? OCF1A v� OCF1B
	OUT		TIFR1,R17 ;x�a c? OCF1A v� OCF1B n?u c�c c? =1
	RET
USART_Init:
    ; Set baud rate to 9600 bps with 8MHz clock
    LDI	R16, 103
    STS	UBRR0L, R16
	;set double speed
    LDI	R16,(1 << U2X0)
    STS	UCSR0A,R16
    ; Set frame format: 8 data bits, no parity, 1 stop bit
    LDI	R16,(1 << UCSZ01) | (1 << UCSZ00)
    STS	UCSR0C,R16
    ; Enable transmitter and receiver
    LDI	R16,(1 << RXEN0) | (1 << TXEN0)
    STS	UCSR0B,R16
    RET

;send out 1 byte in r16
USART_SendChar:
    PUSH	R17
    ; Wait for the transmitter to be ready
    USART_SendChar_Wait:
    LDS		R17,UCSR0A
    SBRS	R17,UDRE0		;check USART Data Register Empty bit
    RJMP	USART_SendChar_Wait
    STS		UDR0,R16		;send out
    POP		R17
    RET

;receive 1 byte in r16
USART_ReceiveChar:
    PUSH	R17
    ; Wait for the transmitter to be ready
    USART_ReceiveChar_Wait:
    LDS	R17,UCSR0A
    SBRS	R17, RXC0	;check USART Receive Complete bit
    RJMP	USART_ReceiveChar_Wait
    LDS	R16,UDR0		;get data
    POP	R17
    RET

	;Display
DISPLAY_V:
;A*Vref = A*5
	LDS AL,ADCL
	LDS AH,ADCH
	
	LDI BL,LOW(3)       ;Load multiplier into BH:BL
    LDI BH,HIGH(3)      ;
	RCALL MUL16x16	;Reusult is stored in: R21,R20
;V=x.--------------------------------------------------------------------------------
	;A*5/1024
	;Ketqua: R0:is the integer part, display it on LCD. R2,R3 is the remainder.
	MOV AL,R20
	MOV AH,R21
	LDI BL,LOW(512)       ;Load multiplier into BH:BL
    LDI BH,HIGH(512)      ;
	RCALL DIV1616

	;display the integer part x._
	MOV		R16,R0
	LDI		R17,0x30
	ADD		R16,R17
	MOV		R17, R16
	
	RCALL	USART_SendChar
	RCALL	WRITE_DATA
	LDI		R17,0x30

	LDI		R16,46	; "."
	RCALL	USART_SendChar
	MOV		R17, R16
	RCALL	WRITE_DATA
	LDI		R17,0x30
;V=x.x-------------------------------------------------------------------------------
	;remainder*10
	MOV AL,R2
	MOV AH,R3
	LDI BL,LOW(10)       ;Load multiplier into BH:BL
   	 LDI BH,HIGH(10)      ;
	RCALL MUL16x16		;Reusult is stored in: R21,R20

	;reamainder*10/1024
	;R0:integer part, display it on LCD. R2,R3 is remainder.
	MOV AL,R20
	MOV AH,R21
	LDI BL,LOW(512)       ;Load multiplier into BH:BL
    	LDI BH,HIGH(512)      ;
	RCALL DIV1616

	;Display integer part _.x
	MOV		R16,R0
	LDI		R17,0x30
	ADD		R16,R17
	MOV		R17, R16
	RCALL	USART_SendChar
	RCALL	WRITE_DATA
	LDI		R17,0x30
;V=x.xx-----------------------------------------------------------------------------
	;So du*10
	MOV AL,R2
	MOV AH,R3
	LDI BL,LOW(10)       ;Load multiplier into BH:BL
    	LDI BH,HIGH(10)      ;
	RCALL MUL16x16	

	MOV AL,R20
	MOV AH,R21
	LDI BL,LOW(512)       ;Load multiplier into BH:BL
    LDI BH,HIGH(512)      ;
	RCALL DIV1616

	MOV		R16,R0
	LDI		R17,0x30
	ADD		R16,R17
	MOV		R17, R16
	RCALL	USART_SendChar
	RCALL	WRITE_DATA
	LDI		R17,0x30
;V=x.xxx---------------------------------------------------------------------------------

	MOV AL,R2
	MOV AH,R3
	LDI BL,LOW(10)       ;Load multiplier into BH:BL
    	LDI BH,HIGH(10)      
	RCALL MUL16x16	

	MOV AL,R20
	MOV AH,R21
	LDI BL,LOW(512)      ;Load multiplier into BH:BL
    LDI BH,HIGH(512)      ;
	RCALL DIV1616

	MOV		R16,R0
	LDI		R17,0x30
	ADD		R16,R17
	MOV		R17, R16
	RCALL	USART_SendChar
	RCALL	WRITE_DATA
	LDI		R17,0x30

	LDI		R16,0x0A
	RCALL	USART_SendChar	
	LDI		R16,0x0D
	MOV		R17, R16
	RCALL	USART_SendChar
	RCALL	WRITE_DATA
RET

;-----------------------------------------------------------------------------
.DEF ZERO = R2               ;To hold Zero
/*.DEF   AL = R16              ;To hold multiplicand
.DEF   AH = R17
.DEF   BL = R18              ;To hold multiplier
.DEF   BH = R19*/
.DEF ANS1 = R20              ;To hold 32 bit answer
.DEF ANS2 = R21
.DEF ANS3 = R22
.DEF ANS4 = R23

        LDI AL,LOW(42)       ;Load multiplicand into AH:AL
        LDI AH,HIGH(42)      ;
        LDI BL,LOW(10)       ;Load multiplier into BH:BL
        LDI BH,HIGH(10)      ;

MUL16x16:
        CLR ZERO             ;Set R2 to zero
        MUL AH,BH            ;Multiply high bytes AHxBH
        MOVW ANS4:ANS3,R1:R0 ;Move two-byte result into answer

        MUL AL,BL            ;Multiply low bytes ALxBL
        MOVW ANS2:ANS1,R1:R0 ;Move two-byte result into answer

        MUL AH,BL            ;Multiply AHxBL
        ADD ANS2,R0          ;Add result to answer
        ADC ANS3,R1          ;
        ADC ANS4,ZERO        ;Add the Carry Bit

        MUL BH,AL            ;Multiply BHxAL
        ADD ANS2,R0          ;Add result to answer
        ADC ANS3,R1          ;
ADC ANS4,ZERO        ;Add the Carry Bit
RET
;-----------------------------------------------------------------------------
.DEF ANSL = R0            ;To hold low-byte of answer
.DEF ANSH = R1            ;To hold high-byte of answer     
.DEF REML = R2            ;To hold low-byte of remainder
.DEF REMH = R3            ;To hold high-byte of remainder
.DEF   AL = R16           ;To hold low-byte of dividend
.DEF   AH = R17           ;To hold high-byte of dividend
.DEF   BL = R18           ;To hold low-byte of divisor
.DEF   BH = R19           ;To hold high-byte of divisor   
.DEF    C = R20           ;Bit Counter

        LDI AL,LOW(420)   ;Load low-byte of dividend into AL
        LDI AH,HIGH(420)  ;Load HIGH-byte of dividend into AH
        LDI BL,LOW(10)    ;Load low-byte of divisor into BL
        LDI BH,HIGH(10)   ;Load high-byte of divisor into BH
DIV1616:
        MOVW ANSH:ANSL,AH:AL ;Copy dividend into answer
        LDI C,17          ;Load bit counter
        SUB REML,REML     ;Clear Remainder and Carry
        CLR REMH          ;
LOOP:   ROL ANSL          ;Shift the answer to the left
        ROL ANSH          ;
        DEC C             ;Decrement Counter
         BREQ DONE        ;Exit if sixteen bits done
        ROL REML          ;Shift remainder to the left
        ROL REMH          ;
        SUB REML,BL       ;Try to subtract divisor from remainder
        SBC REMH,BH
         BRCC SKIP        ;If the result was negative then
        ADD REML,BL       ;reverse the subtraction to try again
        ADC REMH,BH       ;
        CLC               ;Clear Carry Flag so zero shifted into A 
         RJMP LOOP        ;Loop Back
SKIP:   SEC               ;Set Carry Flag to be shifted into A
         RJMP LOOP
DONE:RET

;------------------------------------------------
// POWERUP_LCD_4BIT 
// Input: None 
// Output: None
// Description: Subroutine to power up the LCD
POWERUP_LCD_4BIT:
    LDI R16, 250              ; Load 250 into R16
    RCALL DELAY_US            ; Call the delay subroutine
    LDI R16, 250              ; Load 250 into R16
    RCALL DELAY_US            ; Call the delay subroutine
    LDI R17, $30              ; Load command to initialize LCD in 8-bit mode
    RCALL OUT_COMMAND         ; Call to output command
    LDI R16, 50               ; Load 50 into R16
    RCALL DELAY_US            ; Call the delay subroutine
    LDI R17, $30              ; Load command to initialize LCD in 8-bit mode again
    RCALL OUT_COMMAND         ; Call to output command
    LDI R16, 2                ; Load delay
    RCALL DELAY_US            ; Call the delay subroutine

	 LDI R17, $20              ; Load command for 4-bit mode
    RCALL OUT_COMMAND         ; Call to output command
    RET

// LCD Initialization Subroutine
// Input: None 
// Output: None
// Description: Initializes the LCD
INIT_LCD_4BIT:
    LDI R17, $28              ; Command for 4-bit mode, 2 lines, 5x8 dots
    CALL WRITE_COMMAND        ; Call to write command
    LDI R17, $01              ; Command to clear the display
    CALL WRITE_COMMAND        ; Call to write command
    LDI R17, $0C              ; Command to turn on display, cursor off
    CALL WRITE_COMMAND        ; Call to write command
    LDI R17, $06              ; Command to shift cursor right
    CALL WRITE_COMMAND        ; Call to write command
    RET

// Subroutine to write command to LCD
// Input: R17 
// Output: None
// Description: Writes command contained in R17 to the LCD.
WRITE_COMMAND: 
    PUSH R17                  ; Save R17 on the stack
    ANDI R17, $F0            ; Output the first 4 bits
    RCALL OUT_COMMAND         ; Call to output command
    POP R17                   ; Restore R17 from the stack
    SWAP R17                  ; Swap nibbles
    ANDI R17, $F0            ; Output the last 4 bits
    RCALL OUT_COMMAND         ; Call to output command
    RET

// Subroutine to write data to LCD
// Input: R17 
// Output: None
// Description: Writes character to LCD according to ASCII code; for example, R17=0x41 displays the letter A
WRITE_DATA: 
    PUSH R17                  ; Save R17 on the stack
    ANDI R17, $F0            ; Output first 4 bits
    RCALL OUT_DATA            ; Call to output data
    POP R17                   ; Restore R17 from the stack
    SWAP R17                  ; Swap nibbles
    ANDI R17, $F0            ; Output last 4 bits
    RCALL OUT_DATA            ; Call to output data
    RET

	OUT_COMMAND:
    OUT LCD_PORT, R17        ; Output command to the LCD port
    CBI LCD_PORT, RS         ; Clear RS
    CBI LCD_PORT, RW         ; Clear RW
    SBI LCD_PORT, EN         ; Set Enable
    NOP                       ; No operation
    CBI LCD_PORT, EN         ; Clear Enable
    LDI R16, 20               ; Load delay
    CALL DELAY_US            ; Call delay subroutine
    RET

OUT_DATA:
    OUT LCD_PORT, R17        ; Output data to the LCD port
    SBI LCD_PORT, RS         ; Set RS for data
    CBI LCD_PORT, RW         ; Clear RW
    SBI LCD_PORT, EN         ; Set Enable
    NOP                       ; No operation
    CBI LCD_PORT, EN         ; Clear Enable
    LDI R16, 20              ; Load delay
    CALL DELAY_US            ; Call delay subroutine
    RET

/* DELAY_US
Input: R16
Output: None
Description: DELAY R16*100 MICROSEC
*/
DELAY_US: 
    MOV R15, R16             ; Move R16 to R15
    LDI R16, 100             ; Load delay value
L1: 
    MOV R14, R16             ; Move delay value to R14
L2: 
    DEC R14                  ; Decrement R14
    NOP                       ; No operation
    BRNE L2                  ; Branch if not equal to zero
    DEC R15                  ; Decrement R15
    BRNE L1                  ; Branch if not equal to zero
RET


	LINE1:  .DB "The value is ",$00